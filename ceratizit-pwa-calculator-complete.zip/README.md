# Ceratizit Ball Nose Calculator (PWA)

This is a fully working Progressive Web App for calculating cutter parameters.

## Hosting Instructions
1. Create a GitHub repository (e.g., ceratizit-calculator).
2. Upload all files from this ZIP.
3. Go to Settings > Pages.
4. Select main branch and root folder.
5. GitHub will publish your PWA at:
   https://yourusername.github.io/ceratizit-calculator/

Your team can install the app on mobile or desktop via 'Add to Home Screen'.
